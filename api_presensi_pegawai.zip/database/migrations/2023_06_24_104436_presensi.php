<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('presensi', function (Blueprint $bp){
            $bp->id('id_presensi');
            $bp->string('nip');
            $bp->string('waktu_masuk');
            $bp->string('lokasi_masuk');
            $bp->string('ip_masuk');
            $bp->string('waktu_tengah');
            $bp->string('lokasi_tengah');
            $bp->string('ip_tengah');
            $bp->string('waktu_pulang');
            $bp->string('lokasi_pulang');
            $bp->string('ip_pulang');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('presensi');
    }
};
